package br.com.alura.linguagensapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LinguagensApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
